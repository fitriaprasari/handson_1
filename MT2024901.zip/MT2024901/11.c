/*
============================================================================
File_Name   : 11.c
Author      : Fitriana Prasari Dewi
Description : 11. Write a program to open a file, duplicate the file descriptor and append the file with both the
// descriptors and check whether the file is updated properly or not.
// a. use dup
// b. use dup2
// c. use fcntl
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main() {
    int fd, fd_dup, fd_dup2, fcntl_result, mode;

    // Open the file for reading and writing
    fd = open("file_fitriana.txt", O_RDWR | O_CREAT, 0666);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    // Duplicate the file descriptor using dup
    fd_dup = dup(fd);
    if (fd_dup == -1) {
        perror("dup");
        return 1;
    }
    puts("After dup1()...");

    // Duplicate the file descriptor using dup2
    fd_dup2 = dup2(fd, 10); // Force descriptor 10
    if (fd_dup2 == -1) {
        perror("dup2");
        return 1;
    }
    puts("After dup2()...");
    
    // Print the file descriptors
    printf("Original FD: %d\n", fd);
    printf("Duplicated FD: %d\n", fd_dup);
    printf("Duplicated FD (forced to 10): %d\n", fd_dup2);

    // Append the file descriptors to the file using fcntl
    char buffer[100];
    sprintf(buffer, "fd: %d, fd_dup: %d, fd_dup2: %d\n", fd, fd_dup, fd_dup2);
    fcntl_result = fcntl(fd, F_SETFD, FD_CLOEXEC, F_GETFL);
    if (fcntl_result == -1) {
        perror("fcntl");
        return 1;
    }
    
    write(fd, buffer, strlen(buffer));

    // Close the file descriptors
    close(fd);
    close(fd_dup);
    close(fd_dup2);

    return 0;
}

// RESULT
// mac@MacMacBook-Pro Handson-1 % ./11          
// After dup1()...
// After dup2()...
// Original FD: 3
// Duplicated FD: 4
// Duplicated FD (forced to 10): 10
// fcntl result: 0
// fcntl work properly
// mac@MacMacBook-Pro Handson-1 % 