/*
============================================================================
File_Name   : 23.c
Author      : Fitriana Prasari Dewi
Description : Write a program to create a Zombie state of the running program.
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>

int main() {
    pid_t pid;

    // Create a new process
    pid = fork();

    if (pid < 0) {
        // If fork() returns a negative value, the creation of the child process failed
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        printf("Child process: PID = %d\n", getpid());
        // Exit immediately
        exit(0);
    } else {
        // Parent process
        printf("Parent process: PID = %d\n", getpid());
        printf("Parent process will now sleep for 30 seconds to allow the child process to become a zombie.\n");
        // Sleep to allow the child process to become a zombie
        sleep(30);

        // Wait for the child process to clean up the zombie process
        // You can comment this out to leave the child process as a zombie
        wait(NULL);
        
        printf("Parent process has cleaned up the child process.\n");
    }

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./23               
// Parent process: PID = 44869
// Parent process will now sleep for 30 seconds to allow the child process to become a zombie.
// Child process: PID = 44870
// Parent process has cleaned up the child process.
// mac@MacMacBook-Pro Handson-1 % 

// check the status 
// mac@MacMacBook-Pro Handson-1 % ps aux | grep '[Z]'
// USER               PID  %CPU %MEM      VSZ    RSS   TT  STAT STARTED      TIME COMMAND
// mac               1507   0.5  0.1 34497956   5536   ??  S    Thu02AM   6:44.64 /Users/mac/Library/Application Support/zoom.us/Plugins/Frameworks/ZoomClips.app/Contents/MacOS/ZoomClips --runasps=TRUE --parentbundlename=zoom.us --action=preload --ClipsRecordingType=0
// mac              45117   0.0  0.0 33600984    452 s006  R+    6:40PM   0:00.00 grep [Z]
// mac@MacMacBook-Pro Handson-1 % 
