/*
============================================================================
File_Name   : 8.c
Author      : Fitriana Prasari Dewi
Description : 8. Write a program to open a file in read only mode, read line by line and display each line as it is read. Close the file when end of file is reached.
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
  
    // Opening file
    FILE *file_ptr;

    // Character buffer that stores the read character
    // till the next iteration
    char ch;

    // Opening file in reading mode
    file_ptr = fopen("file_fitriana.txt", "r");

    if (NULL == file_ptr) {
        printf("file can't be opened \n");
          return EXIT_FAILURE;
    }

    printf("Content of the file are:-: \n");

    // Printing what is written in file
    // character by character using loop.
    while ((ch = fgetc(file_ptr)) != EOF) {
        printf("%c", ch);
    }

    // Closing the file
    fclose(file_ptr);
    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./8
// Content of the file are:-: 
// 1234567890m is simplabcdefghijxt of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.%                                                 
// mac@MacMacBook-Pro Handson-1 % 