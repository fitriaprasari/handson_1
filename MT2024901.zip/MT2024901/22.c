/*
============================================================================
File_Name   : 22.c
Author      : Fitriana Prasari Dewi
Description : 22. Write a program, open a file, call fork, and then write to the file by both the child as well as the parent processes. Check output of the file.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

int main() {
    FILE *file;
    pid_t pid;

    // Open a file for writing
    file = fopen("output.txt", "w");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    // Create a new process
    pid = fork();

    if (pid < 0) {
        // If fork() returns a negative value, the creation of the child process failed
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        fprintf(file, "This is the child process writing to the file.\n");
        printf("Child process writing to the file.\n");
    } else {
        // Parent process
        fprintf(file, "This is the parent process writing to the file.\n");
        printf("Parent process writing to the file.\n");
        // Wait for the child process to finish
        wait(NULL);
    }

    // Close the file
    fclose(file);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./22          
// Parent process writing to the file.
// Child process writing to the file.