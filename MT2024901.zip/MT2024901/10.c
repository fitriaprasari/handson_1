/*
============================================================================
File_Name   : 10.c
Author      : Fitriana Prasari Dewi
Description : 10. Write a program to open a file with read write mode, write 10 bytes, move the file pointer by 10
// bytes (use lseek) and write again 10 bytes.
// a. check the return value of lseek
// b. open the file with od and check the empty spaces in between the data.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    // Open the file in read-write mode, create it if it doesn't exist
    int fd = open("file_fitriana.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) {
        perror("Failed to open file");
        return 1;
    }

    // Write 10 bytes of data
    write(fd, "1234567890", 10);

    // Move the file pointer by 10 bytes
    if (lseek(fd, 10, SEEK_CUR) == -1) {
        perror("lseek failed");
        close(fd);
        return 1;
    }

    // Write another 10 bytes of data
    write(fd, "abcdefghij", 10);

    // Close the file
    close(fd);
    printf("Data written successfully.\n");

    return 0;
}


// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 10.c -o 10         
// mac@MacMacBook-Pro Handson-1 % ./10
// Data written successfully.
// mac@MacMacBook-Pro Handson-1 % 