/*
============================================================================
File_Name   : 6.c
Author      : Fitriana Prasari Dewi
Description : 6. Write a program to take input from STDIN and display on STDOUT. Use only read/write system calls
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>  
#include <stdlib.h>  
int main() {  
 
    char flightid[20];  
    char name[100];
    int milesid;

    printf("Enter your rollid: ");  
    scanf("%s", flightid);  

    printf("Enter your name: ");  
    scanf("%s", name);  

    printf("Enter your miles id: ");  
    scanf("%d", &milesid);

    printf("Name: %s\n", name);  
    printf("Flight Number: %s\n", flightid); 
    printf("Miles id: %d\n", milesid);  

    return 0;  
}  

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 6.c -o 6
// mac@MacMacBook-Pro Handson-1 % ./6         
// Enter your rollid: MT2024901
// Enter your name: FITRIANA
// Enter your miles id: 123456
// Name: FITRIANA
// Flight Number: MT2024901
// Miles id: 123456
// mac@MacMacBook-Pro Handson-1 % 
