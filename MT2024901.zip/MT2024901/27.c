/*
============================================================================
File_Name   : 27.c
Author      : Fitriana Prasari Dewi
Description : // 27. Write a program to execute ls -Rl by the following system calls
// a. execl
// b. execlp
// c. execle
// d. execv
// e. execvp
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    char *args[] = {"ls", "-Rl", NULL};  // Arguments for the exec calls
    char *envp[] = {NULL};  // Environment for execle

    // Uncomment one of the following blocks to test a specific exec variant

    // 1. Using execvp
    
    printf("Using execvp to execute ls -Rl...\n");
    execvp("ls", args);
    perror("execvp failed");
    

    // 2. Using execlp
    
    printf("Using execlp to execute ls -Rl...\n");
    execlp("ls", "ls", "-Rl", NULL);
    perror("execlp failed");
    

    // 3. Using execle
    
    printf("Using execle to execute ls -Rl...\n");
    execle("/bin/ls", "ls", "-Rl", NULL, envp);
    perror("execle failed");
    

    // 4. Using execv

    printf("Using execv to execute ls -Rl...\n");
    execv("/bin/ls", args);
    perror("execv failed");
    

    // If you reach this point, an exec call has failed
    printf("No exec call was made, or the exec call failed.\n");

    return 1;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 27.c -o 27
// mac@MacMacBook-Pro Handson-1 % ./27
// Using execvp to execute ls -Rl...
// total 1200
// -rw-r--r--@ 1 mac  staff   1241 Aug 29 01:52 1.sh
// -rw-r--r--@ 1 mac  staff    982 Aug 30 22:21 10.c
// -rwxr-xr-x@ 1 mac  staff   9008 Aug 31 00:30 11
// -rw-r--r--@ 1 mac  staff   2038 Aug 31 00:29 11.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 11:24 12
// -rw-r--r--@ 1 mac  staff   1414 Aug 31 00:31 12.c
// -rwxr-xr-x@ 1 mac  staff   8632 Aug 31 11:25 13
// -rwxrwxrwx@ 1 mac  staff   1602 Aug 31 11:31 13.c
// -rwxr-xr-x@ 1 mac  staff   8744 Aug 31 11:38 14
// -rw-r--r--@ 1 mac  staff   2029 Aug 31 11:38 14.c
// -rwxr-xr-x@ 1 mac  staff   8488 Aug 31 11:41 15
// -rw-r--r--@ 1 mac  staff   2961 Aug 31 11:42 15.c
// -rwxr-xr-x@ 1 mac  staff   8736 Aug 31 15:41 16
// -rw-r--r--@ 1 mac  staff   2354 Aug 31 16:22 16.c
// -rwxr-xr-x@ 1 mac  staff   8656 Aug 31 16:24 17a
// -rw-r--r--@ 1 mac  staff   1119 Aug 31 16:24 17a.c
// -rwxr-xr-x@ 1 mac  staff   8960 Aug 31 16:21 17b
// -rwxrwxrwx@ 1 mac  staff   2394 Aug 31 16:25 17b.c
// -rwxr-xr-x@ 1 mac  staff   9168 Aug 31 16:42 18
// -rw-r--r--@ 1 mac  staff   4419 Aug 31 16:43 18.c
// -rwxr-xr-x@ 1 mac  staff   8488 Aug 31 16:48 19
// -rw-r--r--@ 1 mac  staff   1238 Aug 31 16:49 19.c
// -rwxrwxrwx@ 1 mac  staff   1820 Aug 29 01:52 2.sh
// -rwxr-xr-x@ 1 mac  staff   8640 Aug 31 16:58 20
// -rw-r--r--@ 1 mac  staff   1373 Aug 31 16:58 20.c
// -rwxr-xr-x@ 1 mac  staff   8616 Aug 31 18:09 21
// -rw-r--r--@ 1 mac  staff   1321 Aug 31 18:10 21.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 18:24 22
// -rw-r--r--@ 1 mac  staff   1543 Aug 31 18:26 22.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 18:38 23
// -rw-r--r--@ 1 mac  staff   2264 Aug 31 18:46 23.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 19:04 24
// -rw-r--r--@ 1 mac  staff   1159 Aug 31 19:06 24.c
// -rwxr-xr-x@ 1 mac  staff   8832 Aug 31 19:13 25
// -rw-r--r--@ 1 mac  staff   2398 Aug 31 19:16 25.c
// -rwxr-xr-x@ 1 mac  staff   8448 Aug 31 19:53 26.c
// -rwxr-xr-x@ 1 mac  staff   8704 Aug 31 20:06 27
// -rwxr-xr-x@ 1 mac  staff   1422 Aug 31 20:06 27.c
// -rwxr-xr-x  1 mac  staff  33312 Aug 23 11:40 3
// -rwxrwxrwx@ 1 mac  staff   1213 Aug 29 01:53 3.c
// -rw-r--r--  1 mac  staff   1168 Aug 23 11:31 3.o
// -rwxr-xr-x  1 mac  staff  33312 Aug 23 11:54 4
// -rw-r--r--  1 mac  staff   1357 Aug 29 01:53 4.c
// -rwxr-xr-x  1 mac  staff  33328 Aug 23 18:34 5
// -rw-r--r--  1 mac  staff   1407 Aug 29 01:53 5.c
// -rwxr-xr-x@ 1 mac  staff   8608 Aug 29 08:18 6
// -rw-r--r--  1 mac  staff   1119 Aug 29 01:53 6.c
// -rwxr-xr-x@ 1 mac  staff   8824 Aug 30 11:41 7
// -rw-r--r--@ 1 mac  staff   1707 Aug 30 11:48 7.c
// -rwxr-xr-x@ 1 mac  staff   8568 Aug 30 12:17 8
// -rw-r--r--@ 1 mac  staff   1092 Aug 30 21:28 8.c
// -rwxr-xr-x@ 1 mac  staff   8880 Aug 30 22:15 9
// -rw-r--r--@ 1 mac  staff   1908 Aug 30 22:17 9.c
// -rw-r--r--@ 1 mac  staff      0 Aug 29 08:44 daemon.c
// -rwxr-xr-x@ 1 mac  staff   8480 Aug 29 08:56 execl
// -rw-r--r--@ 1 mac  staff    200 Aug 29 08:56 execl.c
// -rwxr-xr-x@ 1 mac  staff   8664 Aug 31 19:53 execute_26.c
// -rwxr-x---@ 1 mac  staff      0 Aug 30 11:55 file_fitriana,txt
// -rwxrwxrwx@ 1 mac  staff     30 Aug 31 00:28 file_fitriana.txt
// -rw-r--r--@ 1 mac  staff      0 Aug 30 11:47 file_fitriana_copy.txt
// lrwxr-xr-x@ 1 mac  staff     17 Aug 22 16:24 link_file_fitriana -> file_fitriana.txt
// lrwxr-xr-x@ 1 mac  staff     18 Aug 22 16:32 link_file_fitriana_hard -> file_fitriana2.txt
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_0
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_1
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_2
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_3
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_4
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_5
// prw-r--r--@ 1 mac  staff      0 Aug 22 16:46 myfile
// prw-r--r--@ 1 mac  staff      0 Aug 22 17:02 mypipe
// -rw-r--r--  1 mac  staff      0 Aug 29 01:50 notes
// -rw-r--r--@ 1 mac  staff      0 Aug 29 08:20 notes SS.txr
// -rw-r--r--@ 1 mac  staff     95 Aug 31 18:25 output.txt
// -rw-r--r--@ 1 mac  staff    312 Aug 31 16:43 records.dat
// -rwxr-xr-x  1 mac  staff  33200 Aug 23 18:28 test
// -rw-r--r--  1 mac  staff    231 Aug 23 18:27 test.c
// -rw-r--r--@ 1 mac  staff      1 Aug 31 16:24 ticket_concert.txt
// -rw-r--r--@ 1 mac  staff   1786 Aug 29 09:03 ticket_number.c
// -rw-r--r--@ 1 mac  staff    650 Aug 29 08:59 timestampcount.c
// -rw-r--r--@ 1 mac  staff      0 Aug 29 09:17 waitpid.c
// -rwxr-xr-x@ 1 mac  staff   8800 Aug 30 11:41 zombie
// -rw-r--r--@ 1 mac  staff   1422 Aug 29 09:15 zombie.c
// -rw-r--r--@ 1 mac  staff   1512 Aug 29 09:14 zombie.o
// mac@MacMacBook-Pro Handson-1 % gcc 27.c -o 27
// mac@MacMacBook-Pro Handson-1 % ./27          
// No exec call was made, or the exec call failed.
// mac@MacMacBook-Pro Handson-1 % gcc 27.c -o 27
// mac@MacMacBook-Pro Handson-1 % ./27          
// Using execvp to execute ls -Rl...
// total 1200
// -rw-r--r--@ 1 mac  staff   1241 Aug 29 01:52 1.sh
// -rw-r--r--@ 1 mac  staff    982 Aug 30 22:21 10.c
// -rwxr-xr-x@ 1 mac  staff   9008 Aug 31 00:30 11
// -rw-r--r--@ 1 mac  staff   2038 Aug 31 00:29 11.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 11:24 12
// -rw-r--r--@ 1 mac  staff   1414 Aug 31 00:31 12.c
// -rwxr-xr-x@ 1 mac  staff   8632 Aug 31 11:25 13
// -rwxrwxrwx@ 1 mac  staff   1602 Aug 31 11:31 13.c
// -rwxr-xr-x@ 1 mac  staff   8744 Aug 31 11:38 14
// -rw-r--r--@ 1 mac  staff   2029 Aug 31 11:38 14.c
// -rwxr-xr-x@ 1 mac  staff   8488 Aug 31 11:41 15
// -rw-r--r--@ 1 mac  staff   2961 Aug 31 11:42 15.c
// -rwxr-xr-x@ 1 mac  staff   8736 Aug 31 15:41 16
// -rw-r--r--@ 1 mac  staff   2354 Aug 31 16:22 16.c
// -rwxr-xr-x@ 1 mac  staff   8656 Aug 31 16:24 17a
// -rw-r--r--@ 1 mac  staff   1119 Aug 31 16:24 17a.c
// -rwxr-xr-x@ 1 mac  staff   8960 Aug 31 16:21 17b
// -rwxrwxrwx@ 1 mac  staff   2394 Aug 31 16:25 17b.c
// -rwxr-xr-x@ 1 mac  staff   9168 Aug 31 16:42 18
// -rw-r--r--@ 1 mac  staff   4419 Aug 31 16:43 18.c
// -rwxr-xr-x@ 1 mac  staff   8488 Aug 31 16:48 19
// -rw-r--r--@ 1 mac  staff   1238 Aug 31 16:49 19.c
// -rwxrwxrwx@ 1 mac  staff   1820 Aug 29 01:52 2.sh
// -rwxr-xr-x@ 1 mac  staff   8640 Aug 31 16:58 20
// -rw-r--r--@ 1 mac  staff   1373 Aug 31 16:58 20.c
// -rwxr-xr-x@ 1 mac  staff   8616 Aug 31 18:09 21
// -rw-r--r--@ 1 mac  staff   1321 Aug 31 18:10 21.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 18:24 22
// -rw-r--r--@ 1 mac  staff   1543 Aug 31 18:26 22.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 18:38 23
// -rw-r--r--@ 1 mac  staff   2264 Aug 31 18:46 23.c
// -rwxr-xr-x@ 1 mac  staff   8696 Aug 31 19:04 24
// -rw-r--r--@ 1 mac  staff   1159 Aug 31 19:06 24.c
// -rwxr-xr-x@ 1 mac  staff   8832 Aug 31 19:13 25
// -rw-r--r--@ 1 mac  staff   2398 Aug 31 19:16 25.c
// -rwxr-xr-x@ 1 mac  staff   8448 Aug 31 19:53 26.c
// -rwxr-xr-x@ 1 mac  staff   8832 Aug 31 20:07 27
// -rwxr-xr-x@ 1 mac  staff   1395 Aug 31 20:07 27.c
// -rwxr-xr-x  1 mac  staff  33312 Aug 23 11:40 3
// -rwxrwxrwx@ 1 mac  staff   1213 Aug 29 01:53 3.c
// -rw-r--r--  1 mac  staff   1168 Aug 23 11:31 3.o
// -rwxr-xr-x  1 mac  staff  33312 Aug 23 11:54 4
// -rw-r--r--  1 mac  staff   1357 Aug 29 01:53 4.c
// -rwxr-xr-x  1 mac  staff  33328 Aug 23 18:34 5
// -rw-r--r--  1 mac  staff   1407 Aug 29 01:53 5.c
// -rwxr-xr-x@ 1 mac  staff   8608 Aug 29 08:18 6
// -rw-r--r--  1 mac  staff   1119 Aug 29 01:53 6.c
// -rwxr-xr-x@ 1 mac  staff   8824 Aug 30 11:41 7
// -rw-r--r--@ 1 mac  staff   1707 Aug 30 11:48 7.c
// -rwxr-xr-x@ 1 mac  staff   8568 Aug 30 12:17 8
// -rw-r--r--@ 1 mac  staff   1092 Aug 30 21:28 8.c
// -rwxr-xr-x@ 1 mac  staff   8880 Aug 30 22:15 9
// -rw-r--r--@ 1 mac  staff   1908 Aug 30 22:17 9.c
// -rw-r--r--@ 1 mac  staff      0 Aug 29 08:44 daemon.c
// -rwxr-xr-x@ 1 mac  staff   8480 Aug 29 08:56 execl
// -rw-r--r--@ 1 mac  staff    200 Aug 29 08:56 execl.c
// -rwxr-xr-x@ 1 mac  staff   8664 Aug 31 19:53 execute_26.c
// -rwxr-x---@ 1 mac  staff      0 Aug 30 11:55 file_fitriana,txt
// -rwxrwxrwx@ 1 mac  staff     30 Aug 31 00:28 file_fitriana.txt
// -rw-r--r--@ 1 mac  staff      0 Aug 30 11:47 file_fitriana_copy.txt
// lrwxr-xr-x@ 1 mac  staff     17 Aug 22 16:24 link_file_fitriana -> file_fitriana.txt
// lrwxr-xr-x@ 1 mac  staff     18 Aug 22 16:32 link_file_fitriana_hard -> file_fitriana2.txt
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_0
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_1
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_2
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_3
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_4
// ------x---  1 mac  staff      0 Aug 23 18:34 myFile_5
// prw-r--r--@ 1 mac  staff      0 Aug 22 16:46 myfile
// prw-r--r--@ 1 mac  staff      0 Aug 22 17:02 mypipe
// -rw-r--r--  1 mac  staff      0 Aug 29 01:50 notes
// -rw-r--r--@ 1 mac  staff      0 Aug 29 08:20 notes SS.txr
// -rw-r--r--@ 1 mac  staff     95 Aug 31 18:25 output.txt
// -rw-r--r--@ 1 mac  staff    312 Aug 31 16:43 records.dat
// -rwxr-xr-x  1 mac  staff  33200 Aug 23 18:28 test
// -rw-r--r--  1 mac  staff    231 Aug 23 18:27 test.c
// -rw-r--r--@ 1 mac  staff      1 Aug 31 16:24 ticket_concert.txt
// -rw-r--r--@ 1 mac  staff   1786 Aug 29 09:03 ticket_number.c
// -rw-r--r--@ 1 mac  staff    650 Aug 29 08:59 timestampcount.c
// -rw-r--r--@ 1 mac  staff      0 Aug 29 09:17 waitpid.c
// -rwxr-xr-x@ 1 mac  staff   8800 Aug 30 11:41 zombie
// -rw-r--r--@ 1 mac  staff   1422 Aug 29 09:15 zombie.c
// -rw-r--r--@ 1 mac  staff   1512 Aug 29 09:14 zombie.o
// mac@MacMacBook-Pro Handson-1 % 

