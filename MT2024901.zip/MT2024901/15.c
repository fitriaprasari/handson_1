/*
============================================================================
File_Name   : 15.c
Author      : Fitriana Prasari Dewi
Description : 15. Write a program to display the environmental variable of the user (use environ).
Date        : 17th Aug, 2024.
============================================================================
*/
// 
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <unistd.h>
#include <string.h>

// The environ variable is a pointer to an array of strings representing the environment variables.
extern char **environ;

int main() {
    // Pointer to hold each environment variable.
    char **env = environ;

    // Loop through each environment variable until NULL is encountered.
    while (*env) {
        printf("%s\n", *env);
        env++;
    }

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 15.c -o 15
// mac@MacMacBook-Pro Handson-1 % ./15
// MallocNanoZone=0
// USER=mac
// COMMAND_MODE=unix2003
// __CFBundleIdentifier=com.microsoft.VSCode
// PATH=/opt/local/bin:/opt/local/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/opt/local/bin:/opt/local/sbin:/usr/local/bin
// LOGNAME=mac
// SSH_AUTH_SOCK=/private/tmp/com.apple.launchd.ugH5IGtW0v/Listeners
// HOME=/Users/mac
// SHELL=/bin/zsh
// TMPDIR=/var/folders/x_/55mt9hfd14bf5wyzr7dlnrzc0000gn/T/
// __CF_USER_TEXT_ENCODING=0x1F5:0x0:0x64
// XPC_SERVICE_NAME=0
// XPC_FLAGS=0x0
// ORIGINAL_XDG_CURRENT_DESKTOP=undefined
// SHLVL=1
// PWD=/Users/mac/Documents/Linux Shell Script/excercise/Handson-1
// OLDPWD=/Users/mac/Documents/Linux Shell Script/excercise/Handson-1
// TERM_PROGRAM=vscode
// TERM_PROGRAM_VERSION=1.91.1
// LANG=en_US.UTF-8
// COLORTERM=truecolor
// GIT_ASKPASS=/private/var/folders/x_/55mt9hfd14bf5wyzr7dlnrzc0000gn/T/AppTranslocation/9DC096BC-C6E4-4B99-B9E2-EF584AE92961/d/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass.sh
// VSCODE_GIT_ASKPASS_NODE=/private/var/folders/x_/55mt9hfd14bf5wyzr7dlnrzc0000gn/T/AppTranslocation/9DC096BC-C6E4-4B99-B9E2-EF584AE92961/d/Visual Studio Code.app/Contents/Frameworks/Code Helper (Plugin).app/Contents/MacOS/Code Helper (Plugin)
// VSCODE_GIT_ASKPASS_EXTRA_ARGS=
// VSCODE_GIT_ASKPASS_MAIN=/private/var/folders/x_/55mt9hfd14bf5wyzr7dlnrzc0000gn/T/AppTranslocation/9DC096BC-C6E4-4B99-B9E2-EF584AE92961/d/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass-main.js
// VSCODE_GIT_IPC_HANDLE=/var/folders/x_/55mt9hfd14bf5wyzr7dlnrzc0000gn/T/vscode-git-b097e92bc9.sock
// VSCODE_INJECTION=1
// ZDOTDIR=/Users/mac
// USER_ZDOTDIR=/Users/mac
// TERM=xterm-256color
// _=/Users/mac/Documents/Linux Shell Script/excercise/Handson-1/./15
// mac@MacMacBook-Pro Handson-1 % 