/*
============================================================================
File_Name   : 4.c
Author      : Fitriana Prasari Dewi
Description : 4.Write a program to open an existing file with read write mode. Try O_EXCL flag also
Date        : 17th Aug, 2024.
============================================================================
*/
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main() {
int fd;
mode_t mode = O_RDWR|O_EXCL;

// char pathname = "/Users/mac/Documents/Linux Shell Script/excercise/Handson-1/file_fitriana.txt";

    // Open a file for reading using creat
    fd = open("file_fitriana.txt", mode);
    if (fd == -1) {
        perror("Error Opening File");
        // if (errno == EEXIST) {
        //     perror("File already exists");
        // } else {
        //     perror("open");
        // }
        return 1;
        
    }

    // Read from the file using the file descriptor
    char buffer[100];
    read(fd, buffer, sizeof(buffer));
    // Print the file descriptor
    printf("File %d Opened Successfully \n", fd);


    // Close the file
    close(fd);

    return 0;
}

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 4.c -o 4
// mac@MacMacBook-Pro Handson-1 % ./4         
// File 3 Opened Successfully 
// mac@MacMacBook-Pro Handson-1 % 
