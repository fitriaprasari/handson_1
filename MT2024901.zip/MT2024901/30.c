/*
============================================================================
File_Name   : 30.c
Author      : Fitriana Prasari Dewi
Description : 30. Write a program to run a script at a specific time using a Daemon process.
Date        : 17th Aug, 2024.
============================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>

void create_daemon() {
    pid_t pid;

    // Fork the process
    pid = fork();

    if (pid < 0) {
        // Fork failed
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent process
        exit(EXIT_SUCCESS);
    }

    // Child process becomes the session leader
    if (setsid() < 0) {
        exit(EXIT_FAILURE);
    }

    // Fork again to ensure that the daemon is not a session leader
    pid = fork();

    if (pid < 0) {
        // Fork failed
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Exit the first child process
        exit(EXIT_SUCCESS);
    }

    // Change the working directory to root
    if (chdir("/") < 0) {
        exit(EXIT_FAILURE);
    }

    // Close file descriptors
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    // Optionally, redirect standard file descriptors to /dev/null
    open("/dev/null", O_RDWR);  // stdin
    dup(0);  // stdout
    dup(0);  // stderr
}

void write_log() {
    FILE *log_file;
    time_t now;
    char buffer[100];

    log_file = fopen("/tmp/daemon.log", "a");
    if (!log_file) {
        exit(EXIT_FAILURE);
    }

    now = time(NULL);
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&now));
    fprintf(log_file, "Daemon is running at %s\n", buffer);
    fclose(log_file);
}

int main() {
    create_daemon();

    while (1) {
        write_log();
        sleep(30);  // Sleep for 30 seconds
    }

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc create_daemon.c -o create_daemon     
// mac@MacMacBook-Pro Handson-1 % ./create_daemon
// mac@MacMacBook-Pro Handson-1 % cat /tmp/daemon.log
// Daemon is running at 2024-08-31 22:19:35
// Daemon is running at 2024-08-31 22:20:05
// mac@MacMacBook-Pro Handson-1 % 
