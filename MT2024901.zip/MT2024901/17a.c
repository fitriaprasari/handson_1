/*
============================================================================
File_Name   : 
Author      : Fitriana Prasari Dewi
Description : 
Date        : 17th Aug, 2024.
============================================================================
*/
// 17. Write a program to simulate online ticket reservation. Implement write lock
// Write a program to open a file, store a ticket number and exit. Write a separate program, to
// open the file, implement write lock, read the ticket number, increment the number and print
// the new ticket number then close the file.

#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp = fopen("ticket_concert.txt", "w");
    if (fp == NULL) {
        perror("fopen");
        exit(1);
    }

    int ticket_number = 1; // Initial ticket number
    fprintf(fp, "%d", ticket_number);
    fclose(fp);

    printf("Ticket Concert number %d stored in ticket concert.txt\n", ticket_number);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./17a                 
// Ticket Concert number 1 stored in ticket concert.txt
// mac@MacMacBook-Pro Handson-1 % 
