/*
============================================================================
File_Name   : 19.c
Author      : Fitriana Prasari Dewi
Description : 19. Write a program to find out time taken to execute getpid system call. Use time stamp counter.
Date        : 17th Aug, 2024.
============================================================================
*/
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <x86intrin.h>  // Provides __rdtsc()

inline unsigned long long rdtsc() {
    unsigned long long tsc;
    asm volatile("rdtsc" : "=A"(tsc));
    return tsc;
}

int main() {
    unsigned long long start, end;
    pid_t pid;

    // Read TSC before the system call
    start = __rdtsc();

    // Make the getpid() system call
    pid = getpid();

    // Read TSC after the system call
    end = __rdtsc();

    // Calculate the difference to get the number of clock cycles taken
    printf("PID: %d\n", pid);
    printf("Time taken to execute getpid(): %llu clock cycles\n", end - start);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 19.c -o 19
// mac@MacMacBook-Pro Handson-1 % ./19          
// PID: 23055
// Time taken to execute getpid(): 472 clock cycles
// mac@MacMacBook-Pro Handson-1 % 