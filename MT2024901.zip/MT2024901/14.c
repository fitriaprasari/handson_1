/*
============================================================================
File_Name   : 14.c
Author      : Fitriana Prasari Dewi
Description : 14. Write a program to find the type of a file.
                a. Input should be taken from command line.
                b. program should be able to identify any type of a file.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <unistd.h>
#include <string.h>

int main(){

    FILE *file_ptr;
    char filename[100];

    printf("Enter file name :");
    scanf("%s",filename);

    file_ptr = fopen(filename,"r");

    if (NULL == file_ptr) {
        printf("file is not exist \n");
          return EXIT_FAILURE;
    }

    // Extract file extension
    const char *ext = strrchr(filename, '.');

    if (ext != NULL) {
        ext++;  // Move pointer past the '.'

        // Determine the file type based on the extension
        if (strcmp(ext, "txt") == 0) {
            printf("The file is a text file.\n");
        } else if (strcmp(ext, "jpg") == 0 || strcmp(ext, "jpeg") == 0) {
            printf("The file is an image file (JPEG).\n");
        } else if (strcmp(ext, "png") == 0) {
            printf("The file is an image file (PNG).\n");
        } else if (strcmp(ext, "pdf") == 0) {
            printf("The file is a PDF document.\n");
        } else if (strcmp(ext, "c") == 0) {
            printf("The file is a C source code file.\n");
        } else if (strcmp(ext, "h") == 0) {
            printf("The file is a C header file.\n");
        } else if (strcmp(ext, "exe") == 0) {
            printf("The file is an executable file.\n");
        } else {
            printf("Unknown file type.\n");
        }
    } else {
        printf("The file has no extension.\n");
    }



}

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 14.c -o 14
// mac@MacMacBook-Pro Handson-1 % ./14          
// Enter file name :file_fitriana.txt
// The file is a text file.