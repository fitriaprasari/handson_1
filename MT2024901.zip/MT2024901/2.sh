
# /*
# ============================================================================
# File_Name   : 2.sh
# Author      : Fitriana Prasari Dewi
# Description : 2. Write a simple program to execute in an infinite loop at the background. Go to /proc directory and identify all the process related information in the corresponding proc directory.
# Date        : 17th Aug, 2024.
# ============================================================================
# */

for ((;;))
do echo "Infinite Looping..."
done

# OUTPUT
# mac@MacMacBook-Pro Handson-1 % ./2.sh 
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# Infinite Looping...
# ^C

#Proc files related
#am using MacBook so instead accessing /proc, I used ps and lsof - <pid>
# mac@MacMacBook-Pro excercise % ps            
#   PID TTY           TIME CMD
#   712 ttys000    0:00.05 -zsh
#   989 ttys004    0:00.54 /bin/zsh -il
#  3514 ttys004    7:37.37 sh ./2.sh
#  1403 ttys005    0:00.03 /bin/zsh -i
#  3553 ttys011    0:00.08 /bin/zsh -il
# mac@MacMacBook-Pro excercise % lsof -p 3514 
# COMMAND  PID USER   FD   TYPE DEVICE   SIZE/OFF                NODE NAME
# bash    3514  mac  cwd    DIR    1,5        320             4296139 /Users/mac/Documents/Linux Shell Script/excercise/Handson-1
# bash    3514  mac  txt    REG    1,5    1310352 1152921500312524760 /bin/bash
# bash    3514  mac    0u   CHR   16,4 0x2c5245cd                 659 /dev/ttys004
# bash    3514  mac    1u   CHR   16,4 0x2c5245cd                 659 /dev/ttys004
# bash    3514  mac    2u   CHR   16,4 0x2c5245e1                 659 /dev/ttys004
# bash    3514  mac  255r   REG    1,5        487             4303050 /Users/mac/Documents/Linux Shell Script/excercise/Handson-1/2.sh