/*
============================================================================
File_Name   : 21.c
Author      : Fitriana Prasari Dewi
Description : Write a program, call fork and print the parent and child process id
Date        : 17th Aug, 2024.
============================================================================
*/
//21. Write a program, call fork and print the parent and child process id

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    pid_t pid;

    // Create a new process
    pid = fork();

    if (pid < 0) {
        // If fork() returns a negative value, the creation of the child process failed
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // If fork() returns 0, we are in the child process
        printf("Child process\n");
        printf("Child PID: %d\n", getpid());
        printf("Parent PID: %d\n", getppid());
    } else {
        // If fork() returns a positive value, we are in the parent process
        printf("Parent process\n");
        printf("Parent PID: %d\n", getpid());
        printf("Child PID: %d\n", pid);
    }

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 21.c -o 21
// mac@MacMacBook-Pro Handson-1 % ./21
// Parent process
// Parent PID: 33403
// Child PID: 33405
// Child process
// Child PID: 33405
// Parent PID: 1
// mac@MacMacBook-Pro Handson-1 % 