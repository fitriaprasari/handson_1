/*
============================================================================
File_Name   : 5.c
Author      : Fitriana Prasari Dewi
Description : 5. Write a program to create five new files with infinite loop. Execute the program in the background and check the file descriptor table at /proc/pid/fd.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main(){

    int fj;
    int i;
    char filename;
    mode_t mode = O_CREAT|O_RDWR;

for (i=0; i<6; i++){
    // Open a file for reading using creat
    // filename = ("/Users/mac/Documents/Linux Shell Script/excercise/Handson-1/%d",i);
    char filename[50];
    int number = i;
    char *string = "myFile_";
    sprintf(filename, "%s%d", string, number);
    fj = open(filename, mode);
    if (fj == -1) {
        perror("Error Opening File");
        return 1;
        
    }
    // Print the status
    printf("%s created Successfully \n", filename);
}
    // Close the file
    close(fj);
    return 0;
}

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./5         
// myFile_0 created Successfully 
// myFile_1 created Successfully 
// myFile_2 created Successfully 
// myFile_3 created Successfully 
// myFile_4 created Successfully 
// myFile_5 created Successfully 
// mac@MacMacBook-Pro Handson-1 % 