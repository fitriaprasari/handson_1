/*
============================================================================
File_Name   : 29.c
Author      : Fitriana Prasari Dewi
Description : 29. Write a program to get scheduling policy and modify the scheduling policy (SCHED_FIFO,
SCHED_RR).
Date        : 17th Aug, 2024.
============================================================================

*/
#include <sched.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>

int main() {
    // Get current priority of the calling process
    int priority = getpriority(PRIO_PROCESS, 0);
    if (priority == -1) {
        perror("getpriority");
        return 1;
    }

    printf("Current priority: %d\n", priority);

    // Set a new priority (lower value means higher priority)
    int new_priority = 10;  // Example priority value (range: -20 to 19, where -20 is highest priority)
    if (setpriority(PRIO_PROCESS, 0, new_priority) == -1) {
        perror("setpriority");
        return 1;
    }

    printf("Priority changed to: %d\n", new_priority);

    // Get and print the new priority
    priority = getpriority(PRIO_PROCESS, 0);
    if (priority == -1) {
        perror("getpriority");
        return 1;
    }

    printf("New priority: %d\n", priority);

    return 0;
}
// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 29.c -o 29
// mac@MacMacBook-Pro Handson-1 % ./29
// Current priority: 0
// Priority changed to: 10
// New priority: 10
// mac@MacMacBook-Pro Handson-1 % 