/*
============================================================================
File_Name   : 13.c
Author      : Fitriana Prasari Dewi
Description : 13. Write a program to wait for a STDIN for 10 seconds using select. Write a proper print statement to verify whether the data is available within 10 seconds or not (check in $man 2 select).
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <unistd.h>
#include <string.h>

int main(){
// Define the file descriptor set
    fd_set readfds;

    // Clear the set
    FD_ZERO(&readfds);

    // Add STDIN (file descriptor 0) to the set
    FD_SET(STDIN_FILENO, &readfds);

    // Set the timeout duration (10 seconds)
    struct timeval timeout;
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;

    // Wait for data on STDIN with the given timeout
    int result = select(STDIN_FILENO + 1, &readfds, NULL, NULL, &timeout);

    if (result == -1) {
        perror("select() failed");
        return EXIT_FAILURE;
    } else if (result == 0) {
        printf("No data was entered within 10 seconds.\n");
    } else {
        if (FD_ISSET(STDIN_FILENO, &readfds)) {
            printf("Data is available within 10 seconds.\n");
        }
    }

    return EXIT_SUCCESS;
}

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./13                                  
// test
// Data is available within 10 seconds.

// mac@MacMacBook-Pro Handson-1 % ./13 
// No data was entered within 10 seconds.
// mac@MacMacBook-Pro Handson-1 % 
