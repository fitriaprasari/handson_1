/*
============================================================================
File_Name   : 25.c
Author      : Fitriana Prasari Dewi
Description : 25 Write a program to create three child processes. The parent should wait for a particular child (use
// waitpid system call).
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>

int main() {

    pid_t pids[3];  // Array to hold the PIDs of the child processes
    int i;
    pid_t specific_pid;

    // Create three child processes
    for (i = 0; i < 3; i++) {
        pids[i] = fork();

        if (pids[i] < 0) {
            // If fork() fails
            perror("fork failed");
            exit(1);
        } else if (pids[i] == 0) {
            // Child process
            printf("Child %d: PID = %d\n", i + 1, getpid());
            // Each child process sleeps for a different amount of time
            sleep(i + 1);
            printf("Child %d exiting.\n", i + 1);
            exit(0);
        }
    }

    // Parent process
    printf("Parent process: PID = %d\n", getpid());

    // Wait for a specific child process (e.g., the second child)
    specific_pid = pids[1];  // Let's wait for the second child process

    printf("Parent waiting for child with PID = %d\n", specific_pid);
    
    int status;
    if (waitpid(specific_pid, &status, 0) > 0) {
        if (WIFEXITED(status)) {
            printf("Child %d exited with status %d\n", specific_pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Child %d terminated by signal %d\n", specific_pid, WTERMSIG(status));
        }
    } else {
        perror("waitpid failed");
    }

    // Wait for the remaining child processes
    for (i = 0; i < 3; i++) {
        if (pids[i] != specific_pid) {
            waitpid(pids[i], NULL, 0);
        }
    }

    printf("Parent process exiting.\n");
    return 0;
}

// mac@MacMacBook-Pro Handson-1 % ./25
// Child 1: PID = 57067
// Parent process: PID = 57066
// Parent waiting for child with PID = 57068
// Child 2: PID = 57068
// Child 3: PID = 57069
// Child 1 exiting.
// Child 2 exiting.
// Child 57068 exited with status 0
// Child 3 exiting.
// Parent process exiting.
// mac@MacMacBook-Pro Handson-1 % 
