/*
============================================================================
File_Name   : 9.c
Author      : Fitriana Prasari Dewi
Description : 9. Write a program to print the following information about a given file.
Date        : 17th Aug, 2024.
============================================================================
*/
// 

#define _POSIX_SOURCE
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#undef _POSIX_SOURCE
#include <stdio.h>
#include <time.h>

int main() {
  char fn[]="file_fitriana.txt";
  struct stat info;
  int fd;

  if ((fd = creat(fn, S_IWUSR)) < 0)
    perror("creat() error");
  else {
    if (fstat(fd, &info) != 0)
      perror("fstat() error");
    else {
      puts("fstat() returned:");

        // a. inode
        printf("inode:%d\n",(int) info.st_ino);
        // b. number of hard links
        printf("hardlink:%d\n",(int) info.st_nlink);
        // c. uid
        printf("uid:%d\n",(int) info.st_uid);
        // d. gid
        printf("gid:%d\n",(int) info.st_gid);
        // e. size
        printf("size:%d\n",(int) info.st_size);
        // f. block size
        printf("block size:%d\n",(int) info.st_blksize);
        // g. number of blocks
        printf("blocks:%d\n",(int) info.st_blocks);
        // h. time of last access
        printf("blocks:%d\n",(int) info.st_atime);
        // i. time of last modification
        printf("last modification:%s",ctime(&info.st_mtime));
        // j. time of last change
        printf("last change:%s",ctime(&info.st_ctime));
    }
    close(fd);
    unlink(fn);
  }
}


// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./9         
// fstat() returned:
// inode:4888061
// hardlink:1
// uid:501
// gid:20
// size:0
// block size:4096
// blocks:0
// blocks:1725000042
// last modification:Fri Aug 30 22:15:12 2024
// last change:Fri Aug 30 22:15:12 2024
// mac@MacMacBook-Pro Handson-1 % 