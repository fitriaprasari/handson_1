/*
============================================================================
File_Name   : 26_execute.c
Author      : Fitriana Prasari Dewi
Description : 26. Write a program to execute an executable program.
a. use some executable program
b. pass some input to an executable program. (for example execute an executable of $./a.out name)
Date        : 17th Aug, 2024.
============================================================================
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    char *program = "./26";  // The program to execute
    char *args[] = {"./26", "Namaste", NULL};  // Arguments for the program, including the program name and input

    printf("Executing %s...\n", program);

    // Replace the current process with the specified program
    execvp(program, args);

    // If execvp returns, it must have failed
    perror("execvp failed");
    return 1;
}
// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 26_execute.c -o 26_execute
// mac@MacMacBook-Pro Handson-1 % ./26_execute 
// Executing ./26...
// Hello, Namaste!
// mac@MacMacBook-Pro Handson-1 % 
