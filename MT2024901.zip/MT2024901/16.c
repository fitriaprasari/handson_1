/*
============================================================================
File_Name   : 16.c
Author      : Fitriana Prasari Dewi
Description : 16. Write a program to perform mandatory locking.
a. Implement write lock
b. Implement read lock
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
int main() {
    int fd;
    struct flock lock;

    // Open the file
    fd = open("file_fitriana.txt", O_WRONLY);
    if (fd == -1) {
        perror("Open");
        exit(1);
    }

    // Initialize the lock structure
    lock.l_type = F_RDLCK;    // Set the lock type to read lock
    lock.l_type = F_WRLCK;    // Set the lock type to write lock
    lock.l_whence = SEEK_SET; // Lock from the start of the file
    lock.l_start = 0;         // Start at the beginning of the file
    lock.l_len = 0;           // Lock the whole file
    lock.l_pid = getpid();    // Get the process ID

    // a. Apply the write lock
    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    printf("Write lock applied. Press Enter to release the lock.\n");
    getchar(); // Wait for user input

    // Release the lock
    lock.l_type = F_UNLCK;
    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("fcntl");
        close(fd);
        exit(1);
    }
    printf("Write lock released\n");

    // b. Apply the read lock
    if (fcntl(fd, F_RDLCK, &lock) == -1) {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    printf("\n");
    printf("Read lock will start. Press Enter to start\n");
    getchar(); // Wait for user input
    printf("Read lock applied. Press Enter to release the lock.\n");
    getchar(); // Wait for user input

    // Release the lock
    lock.l_type = F_RDLCK;
    if (fcntl(fd, F_RDLCK, &lock) == -1) {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    printf("Read lock released.\n");


    close(fd);
    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./16 
// Write lock applied. Press Enter to release the lock.

// Write lock released

// Read lock will start. Press Enter to start

// Read lock applied. Press Enter to release the lock.

// Read lock released.
