/*
============================================================================
File_Name   : 7.C
Author      : Fitriana Prasari Dewi
Description : 7. Write a program to copy file1 into file2 ($cp file1 file2).
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <stdlib.h> // For exit()

int main()
{
    FILE *fptr1, *fptr2;
    char filename[100];
    int c;

    printf("Enter the filename to open for reading: ");
    scanf("%s", filename);

    // Open one file for reading
    fptr1 = fopen(filename, "r");
    if (fptr1 == NULL)
    {
        printf("Cannot open file %s\n", filename);
        exit(1);
    }

    printf("Enter the filename to open for writing: ");
    scanf("%s", filename);

    // Open another file for writing
    fptr2 = fopen(filename, "w");
    if (fptr2 == NULL)
    {
        printf("Cannot open file %s\n", filename);
        exit(1);
    }

    // Read contents from file
    while ((c = fgetc(fptr1)) != EOF)
    {
        fputc(c, fptr2);
    }

    printf("Contents copied to %s\n", filename);

    fclose(fptr1);
    fclose(fptr2);
    return 0;
}


// before
// mac@MacMacBook-Pro Handson-1 % ls file_fitriana*      
// file_fitriana.txt       file_fitriana_copy.txt
// mac@MacMacBook-Pro Handson-1 % 


//execution
// mac@MacMacBook-Pro Handson-1 % gcc 7.c -o 7     
// mac@MacMacBook-Pro Handson-1 % ./7

//after
// mac@MacMacBook-Pro Handson-1 % ./7                   
// Enter the filename to open for reading: file_fitriana.txt
// Enter the filename to open for writing: file_fitriana_copy.txt
// Contents copied to file_fitriana_copy.txt
// mac@MacMacBook-Pro Handson-1 % 