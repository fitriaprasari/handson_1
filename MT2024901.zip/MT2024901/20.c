/*
============================================================================
File_Name   : 20.c
Author      : Fitriana Prasari Dewi
Description : 20. Find out the priority of your running program. Modify the priority with nice command.
Date        : 17th Aug, 2024.
============================================================================
*/
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int main() {
    int priority;

    // Get the current priority of this process
    priority = getpriority(PRIO_PROCESS, 0);

    if (priority == -1 && errno != 0) {
        perror("getpriority");
        return 1;
    }

    printf("Current Priority (nice value) of this process: %d\n", priority);
    
    int new_priority = 10; // Example: Increase nice value (lower priority)

    // Set a new priority
    if (setpriority(PRIO_PROCESS, 0, new_priority) == -1) {
        perror("setpriority");
        return 1;
    }

    // Verify that the priority was changed
    priority = getpriority(PRIO_PROCESS, 0);
    printf("New Priority (nice value) of this process: %d\n", priority);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./20          
// Current Priority (nice value) of this process: 0
// New Priority (nice value) of this process: 10
// mac@MacMacBook-Pro Handson-1 % 