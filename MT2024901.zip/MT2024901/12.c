/*
============================================================================
File_Name   : 12.c
Author      : Fitriana Prasari Dewi
Description : 12. Write a program to find out the opening mode of a file. Use fcntl.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
 int main(){
    //open file
    int fd, fd_dup, fd_dup2, fcntl_result, mode;

    // Open the file for reading and writing
    fd = open("file_fitriana.txt", O_RDWR | O_CREAT, 0666);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    fcntl_result = fcntl(fd, F_SETFD, FD_CLOEXEC);
    if (fcntl_result == -1) {
        perror("fcntl");
        return 1;
    }

    mode = fcntl(fd, F_GETFL);

    switch(mode){
    case O_RDONLY: printf("mode : r"); break;
    case O_WRONLY: printf("mode : w"); break;
    case O_APPEND: printf("mode : a"); break;
    case O_RDWR: printf("mode : r and w"); break;
    // default: printf("Unknown mode: %d\n", mode); break;

    printf("fcntl result: %d\n", fcntl_result);
    char buffer[100];
    write(fd, buffer, strlen(buffer));
    puts("fcntl work properly");

    // Close the file descriptors
    close(fd);
 }}

 //RESULT
// mac@MacMacBook-Pro Handson-1 % gcc 12.c -o 12
// mac@MacMacBook-Pro Handson-1 % ./12          
// mode : r and w%