# /*
# ============================================================================
# File_Name   : 1.sh
# Author      : Fitriana Prasari Dewi
# Description : Create the following types of a files using (i) shell command (ii) system call
# a. soft link (symlink system call)
# b. hard link (link system call)
# c. FIFO (mkfifo Library Function or mknod system call)
# Date        : 17th Aug, 2024.
# ============================================================================
# */


# a. soft link (symlink system call)
ln -s file_fitriana.txt link_file_fitriana
# verify
ls -l file_fitriana.txt link_file_fitriana
# output
# mac@MacMacBook-Pro Handson-1 % ln -s file_fitriana.txt link_file_fitriana
# mac@MacMacBook-Pro Handson-1 % ls -l file_fitriana.txt link_file_fitriana 
# -rw-r--r--@ 1 mac  staff  11 Aug 22 16:23 file_fitriana.txt
# lrwxr-xr-x@ 1 mac  staff  17 Aug 22 16:24 link_file_fitriana -> file_fitriana.txt

# b. hard link (link system call)
ln -s file_fitriana2.txt link_file_fitriana_hard
#verify
ls -l
#ouptut
# mac@MacMacBook-Pro Handson-1 % ln -s file_fitriana2.txt link_file_fitriana_hard
# mac@MacMacBook-Pro Handson-1 % ls -s file_fitriana2.txt link_file_fitriana_hard
# 8 file_fitriana2.txt            8 link_file_fitriana_hard


