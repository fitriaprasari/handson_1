/*
============================================================================
File_Name   : 24.c
Author      : Fitriana Prasari Dewi
Description : 24. Write a program to create an orphan process
Date        : 17th Aug, 2024.
============================================================================
*/
// 

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>

int main() {
    pid_t pid;

    // Create a new process
    pid = fork();

    if (pid < 0) {
        // If fork() fails
        perror("fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        sleep(5);  // Sleep to ensure the parent terminates first
        printf("Child process: PID = %d, Parent PID = %d\n", getpid(), getppid());
    } else {
        // Parent process
        printf("Parent process: PID = %d\n", getpid());
        printf("Parent process terminating...\n");
        exit(0);  // Parent exits
    }

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./24 
// Parent process: PID = 53917
// Parent process terminating...
// mac@MacMacBook-Pro Handson-1 % Child process: PID = 53918, Parent PID = 1

