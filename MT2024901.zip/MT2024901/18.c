/*
============================================================================
File_Name   : 18.c
Author      : Fitriana Prasari Dewi
Description : 
                18. Write a program to perform Record locking.
                a. Implement write lock
                b. Implement read lock
                // Create three records in a file. Whenever you access a particular record, first lock it then modify/access
                // to avoid race condition.
Date        : 17th Aug, 2024.
============================================================================
*/


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

typedef struct {
    int id;
    char data[100];
} Record;

void write_lock_record(int fd, int record_num, const char *new_data) {
    struct flock lock;
    Record rec;

    // Calculate the offset of the record
    off_t offset = record_num * sizeof(Record);

    // Initialize the lock structure for a write lock
    lock.l_type = F_WRLCK;    // Write lock
    lock.l_whence = SEEK_SET; // Lock from the start of the file
    lock.l_start = offset;    // Start at the specific record
    lock.l_len = sizeof(Record); // Lock only the size of one record
    lock.l_pid = getpid();

    // Apply the write lock
    if (fcntl(fd, F_SETLKW, &lock) == -1) {
        perror("fcntl");
        exit(1);
    }

    // Move the file pointer to the specific record
    lseek(fd, offset, SEEK_SET);

    // Read the current record
    if (read(fd, &rec, sizeof(Record)) != sizeof(Record)) {
        perror("read");
        exit(1);
    }

    printf("Current Record %d: ID = %d, Data = %s\n", record_num + 1, rec.id, rec.data);

    // Modify the record
    strncpy(rec.data, new_data, sizeof(rec.data));
    lseek(fd, offset, SEEK_SET); // Rewind to the start of the record

    // Write the new record
    if (write(fd, &rec, sizeof(Record)) != sizeof(Record)) {
        perror("write");
        exit(1);
    }

    printf("Modified Record %d: ID = %d, Data = %s\n", record_num + 1, rec.id, rec.data);

    // Release the lock
    lock.l_type = F_UNLCK;
    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("fcntl");
        exit(1);
    }
}

void read_lock_record(int fd, int record_num) {
    struct flock lock;
    Record rec;

    // Calculate the offset of the record
    off_t offset = record_num * sizeof(Record);

    // Initialize the lock structure for a read lock
    lock.l_type = F_RDLCK;    // Read lock
    lock.l_whence = SEEK_SET; // Lock from the start of the file
    lock.l_start = offset;    // Start at the specific record
    lock.l_len = sizeof(Record); // Lock only the size of one record
    lock.l_pid = getpid();

    // Apply the read lock
    if (fcntl(fd, F_SETLKW, &lock) == -1) {
        perror("fcntl");
        exit(1);
    }

    // Move the file pointer to the specific record
    lseek(fd, offset, SEEK_SET);

    // Read the locked record
    if (read(fd, &rec, sizeof(Record)) != sizeof(Record)) {
        perror("read");
        exit(1);
    }

    // Print the record data
    printf("Read Record %d: ID = %d, Data = %s\n", record_num + 1, rec.id, rec.data);

    // Release the read lock
    lock.l_type = F_UNLCK;
    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("fcntl");
        exit(1);
    }
}

int main() {
    int fd;
    Record records[3] = {{1, "Record One"}, {2, "Record Two"}, {3, "Record Three"}};

    // Create the file and write initial records
    fd = open("records.dat", O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("open");
        exit(1);
    }

    // Write the initial records to the file
    if (write(fd, records, sizeof(records)) != sizeof(records)) {
        perror("write");
        close(fd);
        exit(1);
    }

    // Example usage of the locking functions:
    
    // Lock, read, and modify the second record
    printf("Applying write lock and modifying the second record:\n");
    write_lock_record(fd, 1, "Updated Record Two");

    // Lock and read the first record
    printf("\nApplying read lock and reading the first record:\n");
    read_lock_record(fd, 0);

    close(fd);
    return 0;
}

//OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./18
// Applying write lock and modifying the second record:
// Current Record 2: ID = 2, Data = Record Two
// Modified Record 2: ID = 2, Data = Updated Record Two

// Applying read lock and reading the first record:
// Read Record 1: ID = 1, Data = Record One
