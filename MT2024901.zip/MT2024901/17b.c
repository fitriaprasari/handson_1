/*
============================================================================
File_Name   : 
Author      : Fitriana Prasari Dewi
Description : 
Date        : 17th Aug, 2024.
============================================================================
*/
// 17. Write a program to simulate online ticket reservation. Implement write lock
// Write a program to open a file, store a ticket number and exit. Write a separate program, to
// open the file, implement write lock, read the ticket number, increment the number and print
// the new ticket number then close the file.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd;
    struct flock lock;
    FILE *fp;

    // Open the file descriptor for locking
    fd = open("ticket_concert.txt", O_RDWR);
    if (fd == -1) {
        perror("open");
        exit(1);
    }

    // Initialize the lock structure
    lock.l_type = F_WRLCK;    // Set the lock type to write lock
    lock.l_whence = SEEK_SET; // Lock from the start of the file
    lock.l_start = 0;         // Start at the beginning of the file
    lock.l_len = 0;           // Lock the whole file
    lock.l_pid = getpid();    // Get the process ID

    // Apply the lock
    if (fcntl(fd, F_SETLKW, &lock) == -1) {
        perror("fcntl");
        close(fd);
        exit(1);
    }

    // Open the file stream for reading and writing
    fp = fdopen(fd, "r+");
    if (fp == NULL) {
        perror("fdopen");
        close(fd);
        exit(1);
    }

    int ticket_number;
    fscanf(fp, "%d", &ticket_number); // Read the ticket number
    printf("Current ticket concert number: %d\n", ticket_number);

    ticket_number++; // Increment the ticket number
    rewind(fp);      // Rewind the file pointer to the beginning
    fprintf(fp, "%d", ticket_number); // Write the new ticket number
    fflush(fp);      // Ensure all output is written to the file

    printf("New ticket concert number: %d\n", ticket_number);

    // Release the lock
    lock.l_type = F_UNLCK;
    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("fcntl");
        fclose(fp);
        close(fd);
        exit(1);
    }

    fclose(fp);
    close(fd);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % ./17b
// Current ticket concert number: 1
// New ticket concert number: 2
// mac@MacMacBook-Pro Handson-1 % 
