/*
============================================================================
File_Name   : 3.c
Author      : Fitriana Prasari Dewi
Description : 3. Write a program to create a file and print the file descriptor value. Use creat ( ) system call
Date        : 17th Aug, 2024.
============================================================================
*/

#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main() {
int fd;
mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
// char pathname = "/Users/mac/Documents/Linux Shell Script/excercise/Handson-1/file_fitriana.txt";

    // Open a file for reading using creat
    fd = creat("file_fitriana.txt", mode);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    // Read from the file using the file descriptor
    char buffer[100];
    read(fd, buffer, sizeof(buffer));
    // Print the file descriptor
    printf("File descriptor: %d\n", fd);

    // Close the file
    close(fd);

    return 0;
}

// OUTPUT
// mac@MacMacBook-Pro Handson-1 % gcc 3.c -o 3
// mac@MacMacBook-Pro Handson-1 % ./3         
// File descriptor: 3
// mac@MacMacBook-Pro Handson-1 % 